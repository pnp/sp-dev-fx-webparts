import axios from 'axios';

const API_KEY = process.env.API_KEY;
const API_URL = process.env.API_URL;

const completion = async (context: any, req: any): Promise<void> => {
  try {
    const response = await axios.post(
      API_URL,
      {
        model: "text-davinci-003",
        prompt: req.body.prompt,
        max_tokens: 2048,
        temperature: 0.7,
        top_p: 1,
        frequency_penalty: 0,
        presence_penalty: 0,
      },
      {
        headers: {
          Authorization: `Bearer ${API_KEY}`,
          "Content-Type": "application/json",
          "User-Agent": "OpenAI",
        },
      }
    );
    context.res = {
      status: 200,
      body: response.data,
    };
  } catch (error) {
    context.res = {
      status: 500,
      body: "Error: Could not complete the prompt",
    };
  }
};

export default completion;
