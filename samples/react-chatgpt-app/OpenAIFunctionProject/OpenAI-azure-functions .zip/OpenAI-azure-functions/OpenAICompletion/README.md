### OpenAI-Azure-functions


# Deploy 
 
To deploy you can use the Azure Extensions for VSCODE , go to "WORKSPACE" and on top Options select Deploy.

![azurefunction](./assets/deploy.png)


# Secure Azure Function App

The Azure Fucntion is secured by Authentication after deployed go to Azure and select Function App and select the Azure Function App created "OpenAIFunctionsApp" 

![azurefunction](./assets/functionApp.png)


# configure authentication

Select Authentications and you have option to create a new Azure App or select a one already created.

in this sample , create a new one.

![azurefunction](./assets/authentication.png)

After go to CORS and add your SharePoint address.

![azurefunction](./assets/cors.png)


# Application Settings

The function needs to have the followed  envoriment vars defined:

![azurefunction](./assets/ApplicationSettings.png)

* The API_KEY is the Key you get from https://platform.openai.com/
* The API_URL is the endpoint to call https://api.openai.com/v1/completions
