import axios from 'axios';

const API_KEY = process.env.API_KEY;
const API_URL = process.env.API_URL;

enum ERole {
  user = "user",
  assistant = "assistant",
  system = "system",
}
interface IMessages {
  role:ERole;
  content: string;
}

const messages: IMessages[] = [];
const completion = async (context: any, req: any): Promise<void> => {
  try {
    messages.push({role:ERole.user,content:req.body.prompt});
    const response = await axios.post(
      API_URL,
     {
      model: "gpt-3.5-turbo",
      messages:messages
      },
      {
        headers: {
          Authorization: `Bearer ${API_KEY}`,
          "Content-Type": "application/json"
        },
      }
    );
    messages.push(response.data.choices[0].message);
    context.res = {
      status: 200,
      body: response.data,
    };
  } catch (error) {

    context.log(`[API Call Error]: error: ${error}`);
    context.res = {
      status: 500,
      body:  error,
    };
  }
};

export default completion;
