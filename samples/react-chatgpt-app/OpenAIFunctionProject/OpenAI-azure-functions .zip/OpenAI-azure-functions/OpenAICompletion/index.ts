import axios from 'axios';

const API_KEY = process.env.API_KEY;
const API_URL = process.env.API_URL;

const completion = async (context: any, req: any): Promise<void> => {
  try {
    const response = await axios.post(
      API_URL,
      {
        model: "gpt-3.5-turbo",
        messages: req.body.messages,
      },
      {
        headers: {
          Authorization: `Bearer ${API_KEY}`,
          "Content-Type": "application/json",
        },
      }
    );
    context.res = {
      status: 200,
      body: response.data,
    };
  } catch (error) {
    context.log(`[API Call Error]: error: ${error}`);
    context.res = {
      status: 500,
      body: error,
    };
  }
};

export default completion;
